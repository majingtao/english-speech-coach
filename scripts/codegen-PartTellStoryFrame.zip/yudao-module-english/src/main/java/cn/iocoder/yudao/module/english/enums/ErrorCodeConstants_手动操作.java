// TODO 待办：请将下面的错误码复制到 yudao-module-english 模块的 ErrorCodeConstants 类中。注意，请给“TODO 补充编号”设置一个错误码编号！！！
// ========== 讲故事 - 单帧 TODO 补充编号 ==========
ErrorCode PART_TELL_STORY_FRAME_NOT_EXISTS = new ErrorCode(TODO 补充编号, "讲故事 - 单帧不存在");