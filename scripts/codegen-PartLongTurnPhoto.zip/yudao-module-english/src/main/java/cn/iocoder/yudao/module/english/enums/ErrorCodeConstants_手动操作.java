// TODO 待办：请将下面的错误码复制到 yudao-module-english 模块的 ErrorCodeConstants 类中。注意，请给“TODO 补充编号”设置一个错误码编号！！！
// ========== 独立长答 - 图片描述 TODO 补充编号 ==========
ErrorCode PART_LONG_TURN_PHOTO_NOT_EXISTS = new ErrorCode(TODO 补充编号, "独立长答 - 图片描述不存在");